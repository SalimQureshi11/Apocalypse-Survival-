using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    public enum ItemType { Food, Water }
    public ItemType itemType;
    public float value = 25f;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerVitals vitals = other.GetComponent<PlayerVitals>();
            if (vitals != null)
            {
                if (itemType == ItemType.Food)
                    vitals.Eat(value);
                else
                    vitals.Drink(value);
            }

            Destroy(gameObject);
        }
    }
}