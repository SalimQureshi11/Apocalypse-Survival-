using UnityEngine;
using UnityEngine.UI;

public class PlayerVitals : MonoBehaviour
{
    public float hunger = 100f;
    public float thirst = 100f;
    public float decayRate = 5f;

    public Slider hungerSlider;
    public Slider thirstSlider;

    void Start()
    {
        hungerSlider.maxValue = 100;
        thirstSlider.maxValue = 100;
    }

    void Update()
    {
        hunger -= decayRate * Time.deltaTime * 0.5f;
        thirst -= decayRate * Time.deltaTime;

        hunger = Mathf.Clamp(hunger, 0, 100);
        thirst = Mathf.Clamp(thirst, 0, 100);

        hungerSlider.value = hunger;
        thirstSlider.value = thirst;

        if (hunger <= 0 || thirst <= 0)
        {
            Debug.Log("Player has died of hunger or thirst.");
        }
    }

    public void Eat(float amount)
    {
        hunger = Mathf.Min(hunger + amount, 100f);
    }

    public void Drink(float amount)
    {
        thirst = Mathf.Min(thirst + amount, 100f);
    }
}