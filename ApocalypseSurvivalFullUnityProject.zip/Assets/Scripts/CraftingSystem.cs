using UnityEngine;

public class CraftingSystem : MonoBehaviour
{
    public GameObject campfirePrefab;
    public Transform spawnPoint;
    public int wood = 0;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.C) || Input.GetButtonDown("Fire1"))
        {
            if (wood >= 3)
            {
                Instantiate(campfirePrefab, spawnPoint.position, Quaternion.identity);
                wood -= 3;
            }
        }
    }

    public void CollectWood(int amount)
    {
        wood += amount;
    }
}