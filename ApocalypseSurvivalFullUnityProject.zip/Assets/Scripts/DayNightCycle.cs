using UnityEngine;

public class DayNightCycle : MonoBehaviour
{
    public Light directionalLight;
    public float daySpeed = 1f;

    void Update()
    {
        directionalLight.transform.Rotate(Vector3.right, daySpeed * Time.deltaTime);
    }
}